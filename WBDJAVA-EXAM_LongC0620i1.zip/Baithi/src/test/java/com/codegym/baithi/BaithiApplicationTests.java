package com.codegym.baithi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaithiApplicationTests {

    @Test
    void contextLoads() {
    }

}
