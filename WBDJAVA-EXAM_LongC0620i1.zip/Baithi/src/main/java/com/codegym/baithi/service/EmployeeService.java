package com.codegym.baithi.service;

import com.codegym.baithi.model.Employee;

public interface EmployeeService extends BaseService<Employee> {
}
