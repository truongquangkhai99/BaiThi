package com.codegym.baithi.service;

import com.codegym.baithi.model.Office;

public interface OfficeService extends BaseService<Office> {
}
